#Exif.js

A JavaScript library for reading EXIF meta data from JPEG image files.